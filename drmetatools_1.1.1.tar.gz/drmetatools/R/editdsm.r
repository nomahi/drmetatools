editdsm　<- function(id,r,n,data=NULL,correct=FALSE){

  data <- data.frame(data)

  id <- data[, deparse(substitute(id))]
  r <- data[, deparse(substitute(r))]
  n <- data[, deparse(substitute(n))]

  id0 <- unique(id); N <- length(id0)
  logRR <- selogRR <- RD <- seRD <- logOR <- selogOR <- NULL

  if(sum(r==0)>0)	message("Caution: The dataset involves zero-cell data.")
  if(sum(r==n)>0)	message("Caution: The dataset involves 100% response data.")

  if(correct==FALSE){

   for(i in 1:N){
	 wi <- which(id==id0[i]); logRRi=c(0); selogRRi=c(NA); RDi=c(0); seRDi=c(NA); logORi=c(0); selogORi=c(NA); 
     for(j in 2:length(wi)){
	   x1 <- r[wi[j]]; n1 <- n[wi[j]]; x0 <- r[wi[1]]; n0 <- n[wi[1]]
	   p1 <- (r[wi[j]])/(n[wi[j]]); p0 <- (r[wi[1]])/(n[wi[1]])
	   err <- p1/p0; erd <- p1-p0; eor <- p1*(1-p0)/(p0*(1-p1))
	   vlrr <- 1/x1 - 1/n1 + 1/x0 - 1/n0
	   vrd <- p1*(1-p1)/n1 + p0*(1-p0)/n0
	   vlor <- 1/x1 + 1/(n1-x1) + 1/x0 + 1/(n0-x0)
       logRRi=c(logRRi,log(err)); selogRRi=c(selogRRi,sqrt(vlrr))
       RDi=c(RDi,erd); seRDi=c(seRDi,sqrt(vrd))
       logORi=c(logORi,log(eor)); selogORi=c(selogORi,sqrt(vlor))
	 }
	 logRR <- c(logRR,logRRi); selogRR <- c(selogRR,selogRRi); RD <- c(RD,RDi); seRD <- c(seRD,seRDi); logOR <- c(logOR,logORi); selogOR <- c(selogOR,selogORi)
   }

   return(data.frame(id=id,r=r,n=n,risk=(r/n),logRR=logRR,selogRR=selogRR,RD=RD,seRD=seRD,logOR=logOR,selogOR=selogOR))

  }

  if(correct==TRUE){

   for(i in 1:N){
	 wi <- which(id==id0[i]); logRRi=c(0); selogRRi=c(NA); RDi=c(0); seRDi=c(NA); logORi=c(0); selogORi=c(NA); 
     for(j in 2:length(wi)){
	   x1 <- r[wi[j]]+0.5; n1 <- n[wi[j]]+1; x0 <- r[wi[1]]+0.5; n0 <- n[wi[1]]+1
	   p1 <- (r[wi[j]]+0.5)/(n[wi[j]]+1); p0 <- (r[wi[1]]+0.5)/(n[wi[1]]+1)
	   err <- p1/p0; erd <- p1-p0; eor <- p1*(1-p0)/(p0*(1-p1))
	   vlrr <- 1/x1 - 1/n1 + 1/x0 - 1/n0
	   vrd <- p1*(1-p1)/n1 + p0*(1-p0)/n0
	   vlor <- 1/x1 + 1/(n1-x1) + 1/x0 + 1/(n0-x0)
       logRRi=c(logRRi,log(err)); selogRRi=c(selogRRi,sqrt(vlrr))
       RDi=c(RDi,erd); seRDi=c(seRDi,sqrt(vrd))
       logORi=c(logORi,log(eor)); selogORi=c(selogORi,sqrt(vlor))
	 }
	 logRR <- c(logRR,logRRi); selogRR <- c(selogRR,selogRRi); RD <- c(RD,RDi); seRD <- c(seRD,seRDi); logOR <- c(logOR,logORi); selogOR <- c(selogOR,selogORi)
   }

   return(data.frame(id=id,r=r,n=n,risk=(r/n),logRR=logRR,selogRR=selogRR,RD=RD,seRD=seRD,logOR=logOR,selogOR=selogOR))

  }

}
